/**
  ******************************************************************************
  * @file    selftest.h
  * @author  
  * @version V1.0
  * @date    28-May-2015
  * @brief   �Լ�
  ******************************************************************************
  */
  
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __SELFTEST_H_
#define __SELFTEST_H_

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"

/* Exported Function----------------------------------------------------------*/
void ElmoShowErr(uint32_t ElmoFlag);

#endif //__SELFTEST_H_
