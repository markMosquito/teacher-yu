/**
  ******************************************************************************
  * @file    CarSelectConfig.h
  * @author  
  * @version V1.0
  * @date    8-May-2015
  * @brief   ѡ��������
  ******************************************************************************
  * 0���ɳ�
  * 1���³�һ��,
  * 2���³�����
  */ 
  
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __CARSELECTCONFIG_H
#define __CARSELECTCONFIG_H


#define CAR_SELECT          (1) 

#endif //__CARSELECTCONFIG_H
